// Difficulty rule: indoor/lifestyle missions are easier; outdoor travel and cleanup missions earn more EXP.
(() => {
  const rules = {
    recycle: { label: '실내 · 쉬움', exp: 20, className: 'easy' }, tumbler: { label: '실내 · 쉬움', exp: 15, className: 'easy' }, reduce: { label: '실내 · 쉬움', exp: 15, className: 'easy' },
    bus: { label: '야외 · 보통', exp: 45, className: 'medium' }, beach: { label: '야외 · 어려움', exp: 60, className: 'hard' }, plogging: { label: '야외 · 어려움', exp: 55, className: 'hard' }
  };
  // The original mission code reads m.exp on completion. Normalize it at lookup time so rewards and saved EXP agree.
  const originalFind = Array.prototype.find;
  Array.prototype.find = function (...args) { const value = originalFind.apply(this, args); if (value?.id && rules[value.id]) value.exp = rules[value.id].exp; return value; };
  function paintDifficulty() {
    document.querySelectorAll('[data-verify]').forEach(button => {
      const rule = rules[button.dataset.verify]; if (!rule) return;
      const card = button.closest('.mission-card, .list-card'); if (!card || card.querySelector('.difficulty-chip')) return;
      const chip = document.createElement('span'); chip.className = `difficulty-chip ${rule.className}`; chip.textContent = rule.label;
      card.querySelector('.mission-info, h3')?.appendChild(chip);
      const reward = card.querySelector('.reward'); if (reward) reward.textContent = `+${rule.exp} EXP · 난이도 보상`;
    });
  }
  new MutationObserver(paintDifficulty).observe(document.querySelector('.app-shell'), { childList: true, subtree: true });
  paintDifficulty();
})();
