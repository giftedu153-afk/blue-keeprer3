// Replaces the decorative map with a georeferenced map and official-data status markers.
(() => {
  const sites = [
    ['해운대해수욕장', 35.1587, 129.1604], ['광안리', 35.1532, 129.1186], ['송도', 35.0778, 129.0192], ['다대포', 35.0469, 128.9656], ['감천항', 35.0722, 129.0040]
  ];
  let map, mapElement;
  async function renderMap() {
    const box = document.querySelector('#map.active .map-board'); if (!box || !window.L) return;
    if (map && mapElement === box) return;
    if (map) map.remove();
    box.innerHTML = ''; box.classList.add('actual-map');
    map = L.map(box, { zoomControl: false, scrollWheelZoom: false }).setView([35.135, 129.055], 11); mapElement = box;
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap contributors', maxZoom: 18 }).addTo(map);
    let live = null;
    try { const r = await fetch('/api/environment'); if (r.ok) live = await r.json(); } catch {}
    sites.forEach(([name, lat, lng]) => {
      const item = live?.items?.find(x => (x.site || '').includes(name.replace('해수욕장','')));
      const text = item ? `<b>${name}</b><br>해양수질 WQI: ${item.water01 ?? '-'}<br>등급: ${item.water02 ?? '-'}` : `<b>${name}</b><br>공식 측정값 연동 대기`;
      L.circleMarker([lat, lng], { radius: 9, color: item ? '#087ea4' : '#e59d31', fillOpacity: .8 }).addTo(map).bindPopup(text);
    });
  }
  new MutationObserver(() => { if (document.querySelector('#map.active')) renderMap(); }).observe(document.querySelector('.app-shell'), { childList: true, subtree: true });
})();
