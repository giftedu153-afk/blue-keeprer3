// Connects Busan's environmental score to Bugi's mood without changing mission history.
(() => {
  const KEY = 'blueKeeperEnvironment';
  let env = JSON.parse(localStorage.getItem(KEY) || '{"health":42,"logs":0}');
  const readLogs = () => JSON.parse(localStorage.getItem('blueKeeper') || '{}').logs?.length || 0;
  const save = () => localStorage.setItem(KEY, JSON.stringify(env));
  if (!env.logs) { env.logs = readLogs(); save(); }
  function sync() {
    const logCount = readLogs();
    if (logCount > env.logs) { env.health = Math.min(100, env.health + (logCount - env.logs) * 3); env.logs = logCount; save(); }
    const bad = env.health < 55;
    document.querySelectorAll('.bugi').forEach(b => b.classList.toggle('unwell', bad));
    const hero = document.querySelector('.hero');
    if (hero && !document.querySelector('.sea-health')) {
      hero.classList.toggle('sea-alert', bad);
      const card = document.createElement('div'); card.className = `sea-health ${bad ? 'unwell' : ''}`;
      card.innerHTML = `<span>🌊 부산 바다 건강도</span><b>${env.health}점</b><i><em style="width:${env.health}%"></em></i><small>${bad ? '부기가 부산 바다를 걱정하고 있어요. 미션으로 도와주세요!' : '부기가 건강하게 바다를 지키고 있어요!'}</small>`;
      hero.insertAdjacentElement('afterend', card);
    }
    const map = document.querySelector('#map.active');
    if (map && !map.querySelector('.map-health')) {
      const title = map.querySelector('.page-title'); const card = document.createElement('div'); card.className = 'map-health';
      card.innerHTML = `<small>오늘의 부산 바다 건강도</small><b>${env.health}<span> / 100</span></b><p>${bad ? '주의: 부기의 컨디션이 나빠졌어요.' : '좋음: 부기가 활기차게 순찰 중이에요.'}</p>`;
      title.insertAdjacentElement('afterend', card);
    }
  }
  function addPhotoGuide() {
    const modal = document.querySelector('.modal');
    if (!modal || modal.querySelector('.ai-photo-guide')) return;
    const title = modal.querySelector('h2')?.textContent || '';
    let detail = '활동 장소와 실천 장면이 한눈에 보이도록 촬영해 주세요.';
    if (title.includes('분리배출')) detail = '분리배출함과 분리한 재활용품이 함께 보이도록 촬영해 주세요.';
    if (title.includes('텀블러')) detail = '텀블러를 사용 중인 모습 또는 음료와 텀블러가 함께 보이도록 촬영해 주세요.';
    if (title.includes('대중교통')) detail = '버스·지하철 내부, 정류장 또는 교통카드 이용 장면이 보여야 해요.';
    if (title.includes('해변') || title.includes('플로깅')) detail = '쓰레기를 줍는 활동, 수거 봉투, 해변 또는 산책로가 함께 보여야 해요.';
    if (title.includes('일회용품')) detail = '다회용품 사용 또는 일회용품을 줄인 실천 장면이 보여야 해요.';
    const guide = document.createElement('div');
    guide.className = 'ai-photo-guide';
    guide.innerHTML = `<b>🤖 AI 인증을 위한 사진 필수 요소</b><span>${detail}</span><small>얼굴·이름·학생증 등 개인정보는 사진에 보이지 않게 해주세요.</small>`;
    modal.querySelector('.upload-area')?.insertAdjacentElement('beforebegin', guide);
  }
  function showRejectionReason() {
    const toast = document.querySelector('#toast');
    const message = toast?.textContent || '';
    if (!message.includes('인증 보류')) return;
    const modal = document.querySelector('.modal');
    if (!modal) return;
    const reason = message.split('·').slice(1).join('·').trim() || '사진에서 미션 활동을 명확하게 확인하지 못했어요.';
    let card = modal.querySelector('.ai-result');
    if (!card) { card = document.createElement('div'); card.className = 'ai-result rejected'; modal.querySelector('#verify-submit')?.insertAdjacentElement('beforebegin', card); }
    card.innerHTML = `<b>AI 인증 보류</b><span>${reason}</span><small>미션 활동이 더 선명하게 보이도록 사진을 다시 촬영해 주세요.</small>`;
  }
  new MutationObserver(sync).observe(document.querySelector('.app-shell'), { childList: true, subtree: true });
  new MutationObserver(addPhotoGuide).observe(document.querySelector('#modal-root'), { childList: true, subtree: true });
  new MutationObserver(showRejectionReason).observe(document.querySelector('#toast'), { childList: true, subtree: true, characterData: true, attributes: true });
  sync();
})();
