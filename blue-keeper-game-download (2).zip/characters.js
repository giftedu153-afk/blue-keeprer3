// First-run character selection. The chosen ocean friend is kept on this device.
(() => {
  const KEY = 'blueKeeperCharacter';
  const friends = [
    { id: 'bugi', icon: '🐦', name: '부기', note: '부산을 사랑하는 갈매기' },
    { id: 'dori', icon: '🐬', name: '도리', note: '빠르게 헤엄치는 돌고래' },
    { id: 'toto', icon: '🐢', name: '토토', note: '느긋한 바다거북' },
    { id: 'momo', icon: '🦦', name: '모모', note: '호기심 많은 수달' }
  ];
  const selected = () => localStorage.getItem(KEY) || 'bugi';
  function paint() {
    const id = selected();
    document.querySelectorAll('.bugi').forEach(el => {
      el.classList.remove(...friends.map(x => `friend-${x.id}`));
      el.classList.add(`friend-${id}`);
    });
  }
  function showPicker(firstRun = false) {
    const root = document.querySelector('#modal-root');
    root.innerHTML = `<div class="character-start"><div class="character-panel"><span class="start-wave">🌊</span><h1>${firstRun ? '함께 바다를 지킬 친구를 골라요!' : '바다 친구 바꾸기'}</h1><p>선택한 친구는 환경 실천과 함께 성장해요.</p><div class="friend-grid">${friends.map(x => `<button class="friend-choice ${x.id === selected() ? 'selected' : ''}" data-friend="${x.id}"><i>${x.icon}</i><b>${x.name}</b><small>${x.note}</small></button>`).join('')}</div><button class="start-game" id="start-game">${firstRun ? '이 친구와 게임 시작하기' : '선택 완료'}</button></div></div>`;
    root.querySelectorAll('[data-friend]').forEach(button => button.onclick = () => {
      localStorage.setItem(KEY, button.dataset.friend);
      root.querySelectorAll('[data-friend]').forEach(x => x.classList.toggle('selected', x === button));
    });
    root.querySelector('#start-game').onclick = () => { root.innerHTML = ''; paint(); };
  }
  function attachChangeButton() {
    const profile = document.querySelector('#profile.active .profile-card');
    if (profile && !profile.querySelector('.change-friend')) {
      const button = document.createElement('button'); button.className = 'change-friend'; button.textContent = '친구 변경'; button.onclick = () => showPicker(false); profile.append(button);
    }
    const hero = document.querySelector('#home.active .hero');
    if (hero && !hero.querySelector('.hero-friend-button')) {
      const friend = friends.find(x => x.id === selected());
      const button = document.createElement('button'); button.className = 'hero-friend-button';
      button.innerHTML = `${friend.icon} ${friend.name} 선택`;
      button.onclick = () => showPicker(false); hero.append(button);
    }
  }
  new MutationObserver(() => { paint(); attachChangeButton(); }).observe(document.querySelector('.app-shell'), { childList: true, subtree: true });
  if (!localStorage.getItem(KEY)) showPicker(true);
  paint(); attachChangeButton();
})();
