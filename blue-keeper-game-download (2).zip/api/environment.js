// Official Busan marine-environment data proxy. Keep the public-data service key on the server.
export default async function handler(req, res) {
  const key = process.env.DATA_GO_KR_SERVICE_KEY;
  if (!key) return res.status(503).json({ error: '공공데이터 API 키가 아직 설정되지 않았습니다.' });
  const url = new URL('https://apis.data.go.kr/6260000/BusanMrnEnvrnInfoService/getMrnEnvrnInfo');
  url.search = new URLSearchParams({ ServiceKey: key, pageNo: '1', numOfRows: '100', resultType: 'json' });
  try {
    const upstream = await fetch(url); const json = await upstream.json();
    const items = json.response?.body?.items?.item || [];
    res.status(200).json({ updatedAt: new Date().toISOString(), items: Array.isArray(items) ? items : [items] });
  } catch { res.status(502).json({ error: '공식 해양환경 측정망 데이터를 불러오지 못했습니다.' }); }
}
