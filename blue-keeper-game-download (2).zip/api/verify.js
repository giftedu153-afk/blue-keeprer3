// Vercel serverless function: keeps the OpenAI key off the user's device.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST 요청만 허용됩니다.' });
  if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: '서버에 OPENAI_API_KEY가 설정되지 않았습니다.' });

  const { mission, image } = req.body || {};
  if (!mission || !image?.startsWith('data:image/')) return res.status(400).json({ error: '미션과 이미지가 필요합니다.' });
  if (image.length > 8_000_000) return res.status(413).json({ error: '사진은 6MB 이하로 올려주세요.' });

  const prompt = `당신은 청소년 환경보호 앱의 사진 인증 심사자입니다. 아래 미션에 사진이 실제로 부합하는지 판단하세요.
미션: ${mission.title} — ${mission.text}
사람의 얼굴, 개인정보, 학교명 등은 평가하지 말고 활동 장면만 판단하세요. 사진이 불명확하거나 관련 활동이 보이지 않으면 approved=false로 하세요.
반드시 아래 JSON만 반환하세요: {"approved":true|false,"confidence":0~100의 정수,"reason":"한국어 한 문장"}`;

  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: process.env.OPENAI_VISION_MODEL || 'gpt-5',
        input: [{ role: 'user', content: [
          { type: 'input_text', text: prompt },
          { type: 'input_image', image_url: image, detail: 'low' }
        ] }]
      })
    });
    if (!response.ok) throw new Error(`OpenAI 요청 실패 (${response.status})`);
    const data = await response.json();
    const text = data.output_text || data.output?.flatMap(x => x.content || []).find(x => x.type === 'output_text')?.text || '';
    const verdict = JSON.parse(text.match(/\{[\s\S]*\}/)?.[0] || '');
    if (typeof verdict.approved !== 'boolean') throw new Error('판정 형식이 올바르지 않습니다.');
    return res.status(200).json({ approved: verdict.approved, confidence: Number(verdict.confidence) || 0, reason: verdict.reason || 'AI 판정 완료' });
  } catch (error) {
    return res.status(502).json({ error: error.message || 'AI 인증에 실패했습니다.' });
  }
}
